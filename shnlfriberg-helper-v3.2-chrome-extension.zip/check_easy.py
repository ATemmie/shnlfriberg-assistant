import json
with open(r'H:\Hermes_Agent\shnlfriberg-extension\players.json', 'r', encoding='utf-8') as f:
    players = json.load(f)

print(f'总选手: {len(players)}')
print(f'简单版池: 前 200 名')
print('前 10 名:')
for p in players[:10]:
    print(f'  {p["name"]:20s} {p["team"]}')
print()
print('第 195-205 名:')
for p in players[194:205]:
    print(f'  id={p["id"]:4d} {p["name"]:20s} {p["team"]}')
print()
print('最后 5 名:')
for p in players[-5:]:
    print(f'  {p["name"]:20s} {p["team"]}')
